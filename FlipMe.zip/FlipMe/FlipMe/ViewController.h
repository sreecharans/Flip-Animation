//
//  ViewController.h
//  FlipMe
//
//  Created by Sree Charan on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,UIGestureRecognizerDelegate>
{
    IBOutlet UIView *view1;
    IBOutlet UIView *iMageView;
    UITextView *promotionView;
    
    IBOutlet UIImageView *slideImage;
    
}

@property (retain, nonatomic) IBOutlet UITableView *tableView;
@property (retain, nonatomic) IBOutlet UIImageView *imageView;
//@property (retain, nonatomic) IBOutlet UIImageView *imageView2;

@end
