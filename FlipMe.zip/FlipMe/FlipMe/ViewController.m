//
//  ViewController.m
//  FlipMe
//
//  Created by Sree Charan on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "RotatingSegue.h"
#import "RotatingFlipSegue.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tableView;
@synthesize imageView;
//@synthesize imageView2;

- (void)viewDidLoad
{
    [super viewDidLoad];
    imageView.hidden = YES;

    UISwipeGestureRecognizer *recognizer;
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(back)];
    [recognizer setDirection:UISwipeGestureRecognizerDirectionRight];
    //[recognizer setNumberOfTouchesRequired:2];
    [imageView addGestureRecognizer:recognizer];
    [recognizer release];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 460)];
    [image setImage:[UIImage imageNamed:@"screen.png"]];
    [self.view addSubview:image];
    [image release];
    
    [self.view bringSubviewToFront:view1];
    
    tableView.separatorColor = [UIColor clearColor];
    tableView.backgroundColor = [UIColor clearColor];
    
    
    promotionView = [[UITextView alloc]initWithFrame:CGRectMake(0, 50, 150, 380)];
    promotionView.text = @"The term promotion is usually an expression used internally by the marketing company, but not normally to the public or the market - phrases like special offer are more common. An example of a fully integrated, long-term, large-scale promotion are My Coke Rewards and Pepsi Stuff. The UK version of My Coke Rewards is Coke Zone.";
    promotionView.backgroundColor = [UIColor clearColor];
    promotionView.font = [UIFont boldSystemFontOfSize:20];
    promotionView.editable = NO;
    promotionView.scrollEnabled = NO;
    [self.view addSubview:promotionView];
    
    //slideImage.backgroundColor = [UIColor redColor];
    
    
  /*UISwipeGestureRecognizer *recognizer;
    recognizer = [[UISwipeGestureRecognizer alloc] init];
    [recognizer setDirection:UISwipeGestureRecognizerDirectionRight | UISwipeGestureRecognizerDirectionLeft];
    [imageView addGestureRecognizer:recognizer];
    [recognizer setDelegate:self];*/
    
    
//    UITapGestureRecognizer *recognizer;
//    recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(back)];
//
//    [recognizer setNumberOfTouchesRequired:2];
//    [self.view addGestureRecognizer:recognizer];
//    [recognizer release];


	// Do any additional setup after loading the view, typically from a nib.
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{

    NSLog(@"%@",gestureRecognizer);return YES;
}

- (void)viewDidUnload
{
    
    [self setTableView:nil];
    [self setImageView:nil];
    //[self setImageView2:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(void)back {
    imageView.hidden = NO;

    NSLog(@"Back Animation is called");
    RotatingFlipSegue *rotate=[[RotatingFlipSegue alloc] init];
    //imageView.frame = CGRectMake(0, 0, 160, 460);
    rotate.source = iMageView;
    rotate.goesForward=FALSE;
    rotate.dest = view1;
    [rotate perform];
    
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	promotionView.frame = CGRectMake((promotionView.frame.origin.x + 150.0), promotionView.frame.origin.y, promotionView.frame.size.width, promotionView.frame.size.height);
    slideImage.frame = CGRectMake((slideImage.frame.origin.x + 280.0), slideImage.frame.origin.y, slideImage.frame.size.width, slideImage.frame.size.height);
	[UIView commitAnimations];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark datasource
-(NSInteger)tableView:(UITableView *)tableView indentationLevelForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 76;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{    
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {  
    return 7;
}

- (UITableViewCell *)tableView:(UITableView *)ktableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *str=@"cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    
    if (cell==nil){
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    cell.textLabel.text=[NSString stringWithFormat:@"row %d",indexPath.section];  
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 160, 76)];
    [image setImage:[UIImage imageNamed:@"vision.png"]];
    [cell.contentView addSubview:image];
    [image release];
    
    
    UISwipeGestureRecognizer *recognizer;
    recognizer = [[UISwipeGestureRecognizer alloc] init];
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeCell)];
    [recognizer setDirection:UISwipeGestureRecognizerDirectionLeft];
    [cell addGestureRecognizer:recognizer];
    [recognizer setDelegate:self];
    
    return cell;
    
}

-(void)swipeCell {
    
    RotatingFlipSegue *rotate=[[RotatingFlipSegue alloc] init];
    rotate.source = view1;
    rotate.dest=imageView;
    rotate.goesForward=TRUE;
    [rotate perform];
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	promotionView.frame = CGRectMake((promotionView.frame.origin.x - 150.0), promotionView.frame.origin.y, promotionView.frame.size.width, promotionView.frame.size.height);
    slideImage.frame = CGRectMake((slideImage.frame.origin.x - 280.0), slideImage.frame.origin.y, slideImage.frame.size.width, slideImage.frame.size.height);
	[UIView commitAnimations];
}

#pragma mark delegate

- (void)tableView:(UITableView *)ktableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"row %d",indexPath.row);
    imageView.hidden = NO;
    
    /*[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	//listTable.frame = CGRectMake((listTable.frame.origin.x - 280.0), listTable.frame.origin.y, listTable.frame.size.width, listTable.frame.size.height);
	imageView.frame = CGRectMake((imageView.frame.origin.x - 280.0), imageView.frame.origin.y, imageView.frame.size.width, imageView.frame.size.height);
	[UIView commitAnimations];*/
    
    NSLog(@"size %@",NSStringFromCGRect(slideImage.frame));
    
    RotatingFlipSegue *rotate=[[RotatingFlipSegue alloc] init];
    rotate.source = view1;
    rotate.dest=imageView;
    rotate.goesForward=TRUE;
    [rotate perform];
    
    
    [UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.4];
	[UIView setAnimationBeginsFromCurrentState:YES];
	promotionView.frame = CGRectMake((promotionView.frame.origin.x - 150.0), promotionView.frame.origin.y, promotionView.frame.size.width, promotionView.frame.size.height);
    slideImage.frame = CGRectMake((slideImage.frame.origin.x - 280.0), slideImage.frame.origin.y, slideImage.frame.size.width, slideImage.frame.size.height);
	[UIView commitAnimations];
    
}
- (void)dealloc {
    [promotionView release];
    [tableView release];
    [imageView release];
  //  [imageView2 release];
    [super dealloc];
}
@end
