//
//  RotatingSegue.h
//  com.si
//
//  Created by Zahur Ghotlawala on 1/31/12.
//  Copyright (c) 2012 Simplified Informatics. All rights reserved.
//


@interface RotatingSegueBack : NSObject
{
    
    CALayer *transformationLayer;
    UIView *hostView;
    BOOL goesForward;
}
@property (nonatomic, retain) id _source;
@property (nonatomic, retain) id destination;
- (void)perform;
@end
